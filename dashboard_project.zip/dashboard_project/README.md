# 🎬 IMDB Movies Analytics Dashboard

> **EDA Course Project** — Interactive Streamlit dashboard exploring 10 000+ IMDB movies
> across genres, ratings, revenue, directors, and more.

---

## 📸 What You'll See

| Section | Charts |
|---|---|
| ⭐ Rating Analysis | Rating histogram · Average rating trend · Genre box plots · Language violin plots |
| 💰 Revenue Analysis | Rating vs Revenue scatter · Correlation heatmap |
| 🎭 Genre Analysis | Genre pie chart · Genre count bar |
| 🎬 Directors & Timeline | Top 10 directors · Cumulative releases per year |

KPI cards at the top always show **Total Movies · Average Rating · Average Revenue · Highest Rated Movie** for the current filter selection.

---

## 🚀 Quick Start

### 1 — Clone / download the project

```
dashboard_project/
├── data/
│   └── imdb_movies.csv   ← put your CSV here
├── notebooks/
│   └── analysis.ipynb
├── app.py
├── charts.py
├── filters.py
├── requirements.txt
└── README.md
```

### 2 — Install dependencies

```bash
pip install -r requirements.txt
```

> Requires **Python 3.9+**

### 3 — Add your dataset

Place your CSV file at `data/imdb_movies.csv`.

**Expected columns** (the loader handles common aliases automatically):

| Column | Description |
|---|---|
| `movie_title` | Film title |
| `year` | Release year (integer) |
| `genre` | Primary genre (Drama, Action, …) |
| `rating` | IMDB rating 0 – 10 |
| `votes` | Number of user votes |
| `revenue` | Box-office gross (numeric or $1,234,567 format) |
| `director` | Director name |
| `cast` | Lead actor / cast list |
| `runtime` | Runtime in minutes |
| `language` | Primary language |
| `country` | Country of production |
| `budget` | Production budget |

> The cleaner handles `$`, commas, `K`/`M`/`B` suffixes, and pipe-separated genre strings automatically.

### 4 — Launch the dashboard

```bash
streamlit run app.py
```

The app opens automatically at **http://localhost:8501**

---

## 🎛️ Filters

All filters live in the left sidebar and update every chart simultaneously:

| Filter | Description |
|---|---|
| 📅 Year Range | Slide to restrict the release-year window |
| 🎭 Genre | Multi-select — leave empty for all genres |
| ⭐ Rating Range | 0.0 – 10.0 slider |
| 🌍 Country | Multi-select — leave empty for all countries |
| 🔍 Title Search | Case-insensitive keyword search |
| 🔄 Reset | Clears all filters in one click |

---

## 📊 Key Insights from the IMDB Dataset

1. **Drama dominates** — Drama consistently represents the largest share of titles across all decades.
2. **Rating sweet spot** — The majority of movies cluster between **6.0 and 7.5**, forming a near-normal distribution.
3. **Revenue ≠ Quality** — High-rated films don't always earn the most; blockbuster franchises can score lower while earning billions.
4. **Golden era directors** — Auteurs like Spielberg, Nolan, and Kubrick consistently maintain average ratings above 7.5.
5. **English language dominance** — English-language films make up the majority, but non-English films often have higher average ratings.
6. **Production boom** — Movie output grew exponentially from the 1980s onward, peaking in the 2010s.

---

## 🗂️ Folder Structure

```
dashboard_project/
│
├── data/
│   └── imdb_movies.csv          # Your dataset goes here
│
├── notebooks/
│   └── analysis.ipynb           # Exploratory analysis notebook
│
├── app.py                       # Streamlit main dashboard
├── charts.py                    # All 10 chart functions (Matplotlib + Seaborn)
├── filters.py                   # Data loading, cleaning & filtering
├── requirements.txt             # Python dependencies
└── README.md                    # This file
```

---

## 🛠 Tech Stack

| Library | Version | Purpose |
|---|---|---|
| Streamlit | ≥ 1.32 | Web dashboard framework |
| Pandas | ≥ 2.0 | Data manipulation |
| NumPy | ≥ 1.24 | Numerical operations |
| Matplotlib | ≥ 3.7 | Core charting |
| Seaborn | ≥ 0.12 | Statistical visualisation |
| SciPy | ≥ 1.10 | KDE overlays (optional) |

---

*Made with ❤️ for the Exploratory Data Analysis course.*
